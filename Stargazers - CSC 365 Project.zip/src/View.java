import javafx.scene.Parent;

public interface View {
    Parent getRoot() throws Exception;
}